import 'package:flutter/material.dart';
import 'package:login_sinup/appBar.dart';
import 'package:login_sinup/post.dart';
import 'package:login_sinup/prodile.dart';
import 'Mystyle.dart';

void main()
{
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
        child: Scaffold(
          backgroundColor: mainColor,
          body: ListView(
            children: [
              Stack(
                children: [
        
        
                  MyPosts(),
                  Profile(),
                  MyAppBar(),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
