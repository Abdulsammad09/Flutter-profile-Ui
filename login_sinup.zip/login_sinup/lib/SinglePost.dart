import 'package:flutter/material.dart';
import 'Mystyle.dart';

class SinglePost extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
         decoration: BoxDecoration(

           borderRadius: BorderRadius.only(
             bottomLeft: Radius.circular(50.0),
             topLeft: Radius.circular(50.0),
           )

         ),
          margin: const EdgeInsets.only(left: 30.0),
          height: 150,
          width: double.infinity,
          child: ClipRRect(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(50.0),
              topLeft: Radius.circular(50.0),
            )
            ,
              child: Image.asset("assets/img.jpeg",fit: BoxFit.cover,),
          ),
        ),

        SizedBox(
          height: 8,
        ),
        Container(
          margin: EdgeInsets.only(left: 80.0, right: 5.0,bottom: 30.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("data", style: postText),
              Row(
                children: [
                  Icon(
                    Icons.comment_bank,
                    size: 16.0,
                    color: Colors.white,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    "15",
                    style: postText,
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Icon(
                    Icons.favorite,
                    size: 16.0,
                    color: Colors.white,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    "150k",
                    style: postText,
                  ),
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
